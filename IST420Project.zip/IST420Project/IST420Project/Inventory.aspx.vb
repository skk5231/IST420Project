﻿
Partial Class Inventory
    Inherits System.Web.UI.Page

End Class
